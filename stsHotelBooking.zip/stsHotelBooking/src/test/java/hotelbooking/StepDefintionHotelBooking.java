package hotelbooking;



import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.PageFactoryHotelBooking;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefintionHotelBooking {
	
	private WebDriver driver;
	private PageFactoryHotelBooking objhb;
	private int i=0;
	
	public void alertMsg() throws InterruptedException {
		String alertMsg=driver.switchTo().alert().getText();
		System.out.println("***********"+alertMsg);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}
	
	
	

@Given("^user is on hotel booking page$")
public void user_is_on_hotel_booking_page() throws Throwable {
	System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
	driver = new ChromeDriver();
    objhb=new PageFactoryHotelBooking(driver);
    //Thread.sleep(1000);
    driver.get("C:\\Users\\AKARGUPT\\Desktop\\stsHotelBooking\\WebContent\\hotelbooking.html");
    
}


@Then("^Title is verified$")
public void title_is_verified() throws Throwable {
	
    
   if(driver.getTitle().contentEquals("Hotel Booking"))
	   System.out.println("********** Title Matched");
   else
	   System.out.println("*********** Title mismatch");
   
   driver.close();
}

@When("^user enters all the valid data$")
public void user_enters_all_the_valid_data() throws Throwable {
	
    
    objhb.setFname("kant");
    objhb.setLname("lavania");
    objhb.setEmail("kant.lavania@capgemini.com");
    objhb.setMobNo("9586682006");
    objhb.setSelCity("Chennai");
    objhb.setSelState("Tamilnadu");
    objhb.setTchname("Sunny R");
    objhb.setDebitNo("9820 3498 6712 ");
    objhb.setCvv("940");
    objhb.setMonth("Mar");
    objhb.setYear("2022");
    Thread.sleep(5000);
}

@Then("^navigate to scucess page$")
public void navigate_to_scucess_page() throws Throwable {
    objhb.setClick();
    System.out.println("all Valid Credentials");
	driver.navigate().to("C:\\Users\\AKARGUPT\\Desktop\\stsHotelBooking\\WebContent\\success.html");
	Thread.sleep(3000);
	System.out.println("Booking Confirmed");
	driver.close();
}



@When("^user leaves first name blank and clicks the button$")
public void user_leaves_first_name_blank_and_clicks_the_button() throws Throwable {
	
	
  
}
@Then("^display alert message$")
public void display_alert_message() throws Throwable {
    objhb.setClick();
    alertMsg();
    driver.close();
}



	


@When("^user enters first name and leaves last name blank$")
public void user_enters_first_name_and_leaves_last_name_blank() throws Throwable {
	System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
	driver = new ChromeDriver();
    objhb=new PageFactoryHotelBooking(driver);
    Thread.sleep(1000);
    driver.get("C:\\Users\\AKARGUPT\\Desktop\\stsHotelBooking\\WebContent\\hotelbooking.html");
	
	objhb.setFname("Kant");
	objhb.setLname("");
	
	Thread.sleep(1000);
}

@When("^user enter incorrect email format$")
public void user_enter_incorrect_email_format() throws Throwable {
	objhb.setFname("Kant");
	objhb.setLname("lavania");
	objhb.setEmail("Kant");
	
	Thread.sleep(1000);
}

@When("^user leaves mobile number blank and clicks the button$")
public void user_leaves_mobile_number_blank_and_clicks_the_button() throws Throwable {
	objhb.setFname("Kant");
	objhb.setLname("lavania");
	objhb.setEmail("kant.lavania@capgemini.com");
	objhb.setMobNo("");
}

@When("^User enters incorrect mobilenumber format and clicks the button$")
public void user_enters_incorrect_mobilenumber_format_and_clicks_the_button(DataTable arg1) throws Throwable {
	List<List<String>> data=arg1.raw();
	objhb.setFname("Kant");
	objhb.setLname("lavania");
	objhb.setEmail("kant.lavania@capgemini.com");Thread.sleep(1000);
	
	
	
	for (i=0;i<data.size();i++) {
		objhb.getMobNo().clear();
		objhb.setMobNo(data.get(i).get(0));
		Thread.sleep(1500);
		objhb.setClick();
		
		
		if(Pattern.matches("^[7-9]{1}[0-9]{9}$",data.get(i).get(0)))
			System.out.println(data.get(i).get(0)+" \tMatched");
			
		else {
			System.out.println(data.get(i).get(0)+"\tMismatched");
			alertMsg();
		}
	}   
}
/*@When("^user enters (\\d+)$")
public void user_enters(String arg1) throws Throwable {
	objhb.setFname("Sunny");
	    objhb.setLname("Revu");
	    objhb.setEmail("sunny.revu@capgemini.com");
	    objhb.setMobNo("8686682006");
	    objhb.setSelCity("Hyderabad");
	    objhb.setSelState("Telangana");
	
	objhb.setNguests(arg1);
}

@Then("^alocate rooms such that (\\d+) room for minimum (\\d+) guests$")
public void alocate_rooms_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
	 String string=driver.findElement(By.xpath(".//*[@id='rooms']")).getText();
	 System.out.println("No of rooms booked : "+string);

}*/

@When("^user enters (\\d+)$")
public void user_enters(String arg1) throws Throwable {
	objhb.setFname("Kant");
    objhb.setLname("lavania");
    objhb.setEmail("kant.lavania@capgemini.com");
    objhb.setMobNo("9886682006");
    objhb.setSelCity("Chennai");
    objhb.setSelState("Tamilnadu");
    objhb.setNguests(arg1);
}

@Then("^for (\\d+) allocate (\\d+)$")
public void for_allocate(int arg1, String arg2) throws Throwable {
		System.out.println("No of Guests : "+objhb.getNguests());
	if(driver.findElement(By.xpath(".//*[@id='rooms']")).getText().equals(arg2))
		{
		
		System.out.println("***** Rooms :"+ arg2);
		}
	else
		{
		System.out.println("Error");
		}
	assertEquals(driver.findElement(By.xpath(".//*[@id='rooms']")).getText(),arg2);

    driver.close();
}


@When("^user does not select any city and clicks the button$")
public void user_does_not_select_any_city_and_clicks_the_button() throws Throwable {
		objhb.setFname("Kant");
	    objhb.setLname("lavania");
	    objhb.setEmail("kant.lavania@capgemini.com");
	    objhb.setMobNo("9486682006");
	    objhb.setSelCity("Select City");
	  
	    Thread.sleep(2000);
}

@When("^user does not select State and clicks the button$")
public void user_does_not_select_State_and_clicks_the_button() throws Throwable {
	 objhb.setFname("Kant");
	    objhb.setLname("lavania");
	    objhb.setEmail("kant.lavania@capgemini.com");
	    objhb.setMobNo("9486682006");
	    objhb.setSelCity("Chennai");
	    objhb.setSelState("Select State");
	   
	    Thread.sleep(2000);
}

@When("^user leaves Card Holder name blank and clicks the button$")
public void user_leaves_Card_Holder_name_blank_and_clicks_the_button() throws Throwable {
	 objhb.setFname("Kant");
	    objhb.setLname("lavania");
	    objhb.setEmail("kant.lavania@capgemini.com");
	    objhb.setMobNo("9486682006");
	    objhb.setSelCity("Chennai");
	    objhb.setSelState("Tamilnadu");
	    objhb.setTchname("");
	   
	    Thread.sleep(2000);
}

@When("^user leaves debit card number blank and clicks the button$")
public void user_leaves_debit_card_number_blank_and_clicks_the_button() throws Throwable {
	 objhb.setFname("Kant");
	    objhb.setLname("lavania");
	    objhb.setEmail("kant.lavania@capgemini.com");
	    objhb.setMobNo("9486682006");
	    objhb.setSelCity("Chennai");
	    objhb.setSelState("Tamilnadu");
	    objhb.setTchname("Kant l");
	    objhb.setDebitNo("");
	    
	    Thread.sleep(2000);
}

@When("^user leaves card expiration month blank and clicks the button$")
public void user_leaves_card_expiration_month_blank_and_clicks_the_button() throws Throwable {
	 	objhb.setFname("Kant");
	    objhb.setLname("lavania");
	    objhb.setEmail("kant.lavania@capgemini.com");
	    objhb.setMobNo("9486682006");
	    objhb.setSelCity("Chennai");
	    objhb.setSelState("Tamilnadu");
	    objhb.setTchname("Kant l");
	    objhb.setDebitNo("7620 9498 7412 ");
	    objhb.setCvv("940");
	    objhb.setMonth("");
	    
	    Thread.sleep(2000);
}

@When("^user leaves card expiration year blank and clicks the button$")
public void user_leaves_card_expiration_year_blank_and_clicks_the_button() throws Throwable {
	 	objhb.setFname("Kant");
	    objhb.setLname("lavania");
	    objhb.setEmail("kant.lavania@capgemini.com");
	    objhb.setMobNo("8686682006");
	    objhb.setSelCity("Chennai");
	    objhb.setSelState("Tamilnadu");
	    objhb.setTchname("Sunny R");
	    objhb.setDebitNo("5620 5698 7412 ");
	    objhb.setCvv("580");
	    objhb.setMonth("Mar");
	    objhb.setYear("");
	    Thread.sleep(5000);
}

@When("^user leaves email blank$")
public void user_leaves_email_blank() throws Throwable {
	objhb.setFname("Kant");
	objhb.setLname("lavania");
	objhb.setEmail("");
	Thread.sleep(2000);
}

@When("^user enters details till cvv and leaves cvv blank$")
public void user_enters_details_till_cvv_and_leaves_cvv_blank() throws Throwable {
	 	objhb.setFname("Kant");
	    objhb.setLname("lavania");
	    objhb.setEmail("kant.lavania@capgemini.com");
	    objhb.setMobNo("9386682006");
	    objhb.setSelCity("Chennai");
	    objhb.setSelState("Tamilnadu");
	    objhb.setTchname("Kant l");
	    objhb.setDebitNo("5920 8298 7412 ");
	    objhb.setCvv("");
	    Thread.sleep(3000);
}
	
	
}



